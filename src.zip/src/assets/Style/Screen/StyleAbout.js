import {StyleSheet} from 'react-native';

export const styleAbout = StyleSheet.create({
  content: {
    marginHorizontal: 20, 
    paddingTop: 10,
    paddingBottom: 10
  },
  title: {
    fontSize: 25, 
    fontFamily: 'Montserrat-Regular', 
    textAlign: 'center', 
    color: '#128ed4', 
    marginBottom: 20    
  },
  image: {
    width: '100%', 
    height: 250, 
    marginBottom: 20,
    borderRadius: 5,
  },
  text: {
    marginBottom: 15, 
    color: '#465a7e', 
    fontFamily: 'Poppins-Regular', 
    fontSize: 12, 
    lineHeight: 18,
  }
});
