import {StyleSheet} from 'react-native';

export const styleAbout = StyleSheet.create({
  content: {
    marginHorizontal: 20, 
    paddingTop: 10
    
  },
  title: {
    fontSize: 25, 
    fontFamily: 'Montserrat-Regular', 
    color: '#128ed4', 
    marginBottom: 20    
  },
  text: {
    marginBottom: 15, 
    color: '#465a7e', 
    fontFamily: 'Poppins-Regular', 
    fontSize: 12, 
    lineHeight: 18,
  }
});
