import axios from 'axios';

export default api = axios.create({
  baseURL: 'http://www.saintmaurpromo.fr/api/',
});