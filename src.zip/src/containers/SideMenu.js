import React from 'react';
import { Text, View, ImageBackground, Image, TouchableOpacity, Share, AsyncStorage, Linking } from 'react-native';
import { SocialIcon } from 'react-native-elements';

import NavigationService from './NavigationService';

import { styleSidebar } from '../assets/Style/Components/StyleSidebar';

class SideMenu extends React.Component {

  // handlePress() {
  //   Share.share({
  //       message: "Installe l'application St Maur Promo pour connaitre tous les événements de la ville ! http://google.com " ,
  //       url: 'http://google.com', // IOS only
  //       title: 'Application St Maur Promo'
  //       }, {
  //       // Android only:
  //       dialogTitle: "Partagez l'application à vos proches",
  //       // iOS only:
  //       excludedActivityTypes: [
  //           'com.apple.UIKit.activity.PostToTwitter'
  //       ]
  //   })
  // } 
  render() {
    return (
      <View>
        <ImageBackground
          source={require('../image/bg-menu.jpg')}
          style={{ width: '100%', height: '100%', zIndex: 2 }}
        >
          <View style={styleSidebar.container}>
            <View>
              <Image
                source={require('../image/logo.png')}
                style={styleSidebar.logo}
              />
              <View>

                <TouchableOpacity style={[
                  styleSidebar.linkMenu,
                  (this.props.currentScreen === 'Home' ? styleSidebar.activeBg : {})
                ]}
                  onPress={() => { NavigationService.navigate("Home") }} >
                  <Image
                    source={
                      (this.props.currentScreen === 'Home' ? (
                        require('../image/menu/home-active.png')
                      ) : (
                          require('../image/menu/home.png')
                        ))
                    }
                    style={{ width: 25, height: 25 }}
                  />
                  <Text style={[
                    styleSidebar.textLink,
                    (this.props.currentScreen === 'Home' ? styleSidebar.activeText : {})
                  ]}>Accueil</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[
                    styleSidebar.linkMenu,
                    (this.props.currentScreen === 'Annonceurs' ? styleSidebar.activeBg : {})
                  ]}
                  onPress={() => { NavigationService.navigate("Annonceurs", search='') }}>
                  <Image
                    source={
                      (this.props.currentScreen === 'Annonceurs' ? (
                        require('../image/menu/annonceurs-active.png')
                      ) : (
                          require('../image/menu/annonceurs.png')
                        ))
                    }
                    style={{ width: 25, height: 25 }}
                  />
                  <Text style={[
                    styleSidebar.textLink,
                    (this.props.currentScreen === 'Annonceurs' ? styleSidebar.activeText : {})
                  ]}>Les annonceurs</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[
                    styleSidebar.linkMenu,
                    (this.props.currentScreen === 'PromosEvents' ? styleSidebar.activeBg : {})
                  ]}
                  onPress={() => { NavigationService.navigate('PromosEvents') }} >
                  <Image
                    source={
                      (this.props.currentScreen === 'PromosEvents' ? (
                        require('../image/menu/promo-events-active.png')
                      ) : (
                          require('../image/menu/promo-events.png')
                        ))
                    }
                    style={{ width: 25, height: 25 }}
                  />
                  <Text style={[
                    styleSidebar.textLink,
                    (this.props.currentScreen === 'PromosEvents' ? styleSidebar.activeText : {})
                  ]}>Les promotions & évements</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[
                    styleSidebar.linkMenu,
                    (this.props.currentScreen === 'Login' ? styleSidebar.activeBg : {})
                  ]}
                  onPress={() => { 
                    AsyncStorage.getItem('id_token').then((token) => {
                      if(token == null){
                        NavigationService.navigate('Login');
                      }else{
                        NavigationService.navigate('EspaceAnnonceur');
                      }
                    })
                    
                  }} >
                  <Image
                    source={
                      (this.props.currentScreen === 'Login' ? (
                        require('../image/menu/connexion-active.png')
                      ) : (
                          require('../image/menu/connexion.png')
                        ))
                    }
                    style={{ width: 25, height: 27 }}
                  />
                  <Text style={[
                    styleSidebar.textLink,
                    (this.props.currentScreen === 'Login' ? styleSidebar.activeText : {})
                  ]}>Mon compte</Text>
                </TouchableOpacity>

                <TouchableOpacity style={[
                  styleSidebar.linkMenu,
                  (this.props.currentScreen === 'About' ? styleSidebar.activeBg : {})
                ]}
                  onPress={() => { NavigationService.navigate('About') }} >
                  <Image
                    source={
                      (this.props.currentScreen === 'About' ? (
                        require('../image/menu/about-active.png')
                      ) : (
                          require('../image/menu/about.png')
                        ))
                    }
                    style={{ width: 30, height: 25 }}
                  />
                  <Text style={[
                    styleSidebar.textLink,
                    (this.props.currentScreen === 'About' ? styleSidebar.activeText : {})
                  ]}>Qui sommes-nous ?</Text>
                </TouchableOpacity>

              </View>
            </View>
          </View>
          <View style={styleSidebar.socialMedia}>
            <TouchableOpacity onPress={()=> Linking.openURL('https://www.facebook.com/saintmaurpromo').catch(err => console.error('An error occurred', err))} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <SocialIcon
                type='facebook'
                raised={true}
              />
            </TouchableOpacity>
          </View>
        </ImageBackground>
      </View>
    );
  }
}

export default SideMenu;
