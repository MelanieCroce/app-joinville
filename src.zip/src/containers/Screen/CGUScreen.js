import React from 'react';
import {connect} from 'react-redux';
import { Text, Image, View, ActivityIndicator } from 'react-native';
import MainLayout from '../../components/Layout/MainLayout';
import {styleAbout} from '../../assets/Style/Screen/StyleCGU';
import { fetchCGU } from '../../actions/contentAbout';

function mapStateToProps( state ) {
  return {
    cgu: state.contentCGUReducer,
  };
}


class CGUScreen extends React.Component {
  static navigationOptions = {
    header: null,
  };  

	componentDidMount() {
    const action = fetchCGU();
    this.props.dispatch( action );
  }
  
  render() {
    if ( this.props.cgu.cgu == null ) {
      return ( 
        <MainLayout>
          <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
            <ActivityIndicator size="large" color="#55bad4" />
          </View>
        </MainLayout>
      )
    }    
    const cgu = this.props.cgu.cgu;    
      return (
        <MainLayout title="CGU" navigation={this.props.navigation}>
          <View style={styleAbout.content}>
            <Text style={styleAbout.title}>{cgu.name}</Text>
            <Text style={styleAbout.text}>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
            </Text>
            <Text style={styleAbout.text}>
              {cgu.text}
            </Text>              
          </View>

        </MainLayout> 
      );
  };
};

export default connect(mapStateToProps)(CGUScreen);